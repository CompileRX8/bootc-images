ls
ls /usr/local
ls /usr/local/bin
/usr/local/bin/gitea help
/usr/local/bin/gitea dump --help
ls /var/lib
ls -l
rm gitea-dump-177342*
ls app-argocd
ls app-config
ls data
ls custom
ls custom/https
ls -ld .
chmod 777 gitea-local-postgresql
ls -l
